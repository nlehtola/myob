﻿// ---------------------------------------------------------------------------------
// MYOB - MYOB.PayslipConsoleApp
// PayslipConsoleController.cs
// DRNL
// 2016.01.19 (c) DRNL
// ---------------------------------------------------------------------------------

using MYOB.Models;

namespace MYOB.PayslipConsoleApp.Models
{
    /// <summary>
    /// Application model
    /// </summary>
    class PayslipConsoleModel : Model
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public PayslipConsoleModel()
        {
            // ...
        }
    }
}

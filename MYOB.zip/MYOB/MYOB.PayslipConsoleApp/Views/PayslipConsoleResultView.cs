﻿// ---------------------------------------------------------------------------------
// MYOB - MYOB.PayslipConsoleApp
// PayslipConsoleResultView.cs
// DRNL
// 2016.01.19 (c) DRNL
// ---------------------------------------------------------------------------------

using MYOB.Views;

namespace MYOB.PayslipConsoleApp.Views
{
    /// <summary>
    /// View class
    /// </summary>
    internal class PayslipConsoleResultView : View
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public PayslipConsoleResultView()
        {
            // Initialize instance variables
        }
    }
}
